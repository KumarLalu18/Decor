package com.decor;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@Slf4j
@SpringBootApplication
public class DecorApplication {

	public static void main(String[] args) {
		log.info("Starting DecorApplication");
		SpringApplication.run(DecorApplication.class, args);
		log.info("DecorApplication started successfully");
	}
}