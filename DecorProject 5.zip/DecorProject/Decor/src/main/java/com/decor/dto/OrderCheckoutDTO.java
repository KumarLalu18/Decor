package com.decor.dto;

import lombok.Data;

@Data
public class OrderCheckoutDTO {
    private CartDTO cart;
    private String shippingAddress;
    private String paymentMethod;
}
