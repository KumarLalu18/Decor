package com.decor.enums;

public enum OrderStatus {
    CONFIRMED,
    CANCELLED,
    SHIPPED,
    DELIVERED,
    RETURNED
}