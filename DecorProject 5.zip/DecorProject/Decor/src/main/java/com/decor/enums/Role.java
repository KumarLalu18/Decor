package com.decor.enums;

public enum Role {
    CUSTOMER,
    ADMIN
}