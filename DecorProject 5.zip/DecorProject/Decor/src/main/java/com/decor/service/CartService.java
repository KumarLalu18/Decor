package com.decor.service;

import com.decor.dto.CartDTO;
import com.decor.dto.CartItemDTO;

public interface CartService {
    CartDTO getUserCart(Long userId);
    CartDTO addOrUpdateCart(CartItemDTO cartItemDTO);
    void clearCart(Long userId);
}