package com.decor.service;

import com.decor.dto.OrderDTO;
import com.decor.dto.OrderCheckoutDTO;

import java.util.List;

public interface OrderService {
    void placeOrder(OrderCheckoutDTO orderCheckoutDTO);
    List<OrderDTO> getOrdersByUser(Long userId);
}