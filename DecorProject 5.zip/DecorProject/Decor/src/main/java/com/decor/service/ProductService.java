package com.decor.service;

import com.decor.dto.ProductDTO;

import java.util.List;

public interface ProductService {
    List<ProductDTO> getAllProducts();
    ProductDTO getProductById(Long productId);
    List<ProductDTO> getProductsByCategory(Long categoryId);
}