package com.decor.service;

import com.decor.dto.UserRequestDTO;
import com.decor.dto.UserLoginDTO;
import com.decor.dto.UserResponseDTO;

public interface UserService {
    UserResponseDTO registerUser(UserRequestDTO userRequestDTO);
    UserResponseDTO loginUser(UserLoginDTO userLoginDTO);
    UserResponseDTO updateUser(Long userId, UserRequestDTO userRequestDTO);
}