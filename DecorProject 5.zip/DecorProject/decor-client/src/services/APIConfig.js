const APIConfig = {
  baseURL: 'http://localhost:8080'
};

export default APIConfig;
